class RandomForestClassifier:
    """Stand-in: training isn't available on a phone, and scanning never needs it."""
    def __init__(self, *args, **kwargs):
        raise RuntimeError("training is not available on this device")
